import { FeatureCollection, Feature } from 'geojson';
import { RegisteredStaticIconReference, SourceUrlStaticIconReference, StaticIconReference } from '@ngageoint/mage.web-core-lib/static-icon';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';

interface Feed {
    id: string;
    service: string;
    topic: string;
    title: string;
    summary?: string;
    icon?: RegisteredStaticIconReference;
    mapStyle?: RegisteredMapStyle;
    itemTemporalProperty?: string;
    itemPrimaryProperty?: string;
    itemSecondaryProperty?: string;
    itemsHaveSpatialDimension?: boolean;
    itemsHaveIdentity?: boolean;
    constantParams?: any;
    variableParamsSchema?: any;
    updateFrequencySeconds?: number;
    itemPropertiesSchema?: any;
}
interface MapStyle {
    icon?: SourceUrlStaticIconReference;
}
interface RegisteredMapStyle {
    icon?: RegisteredStaticIconReference;
}
type StyledFeature = Feature & {
    style: MapStyle;
};
interface ServiceType {
    /**
     * Well-known identifier that the feed plugin creator assigns
     */
    pluginServiceTypeId: string;
    /**
     * The unique identifier MAGE server generates to reference the service type
     */
    id: string;
    title: string;
    summary: string;
    configSchema: any;
}
interface Service {
    id: string;
    title: string;
    serviceType: ServiceType | string;
    summary: string | null;
    config: any;
}
interface FeedTopic {
    id: string;
    title: string;
    summary?: string;
    icon?: SourceUrlStaticIconReference;
    paramsSchema?: any;
    updateFrequencySeconds?: number;
    itemsHaveIdentity?: boolean;
    itemsHaveSpatialDimension?: boolean;
    itemTemporalProperty?: string;
    itemPrimaryProperty?: string;
    itemSecondaryProperty?: string;
    itemPropertiesSchema?: any;
    mapStyle?: MapStyle;
}
type FeedExpanded = Omit<Feed, 'service' | 'topic'> & {
    service: Service;
    topic: FeedTopic;
};
interface FeedContent {
    items: FeatureCollection;
}
interface FeedContent {
    feed: string;
    variableParams?: any;
    items: FeatureCollection;
}
interface FeedPreview {
    feed: Feed;
    content?: FeedContent;
}
type FeedPost = Partial<Omit<Feed, 'service' | 'topic' | 'icon'>> & Pick<Feed, 'service' | 'topic'> & {
    icon?: StaticIconReference;
};

interface FeedPreviewOptions {
    skipContentFetch?: boolean;
}
declare class FeedService {
    private webClient;
    constructor(webClient: HttpClient);
    private _feeds;
    readonly feeds$: Observable<Feed[]>;
    private _feedItems;
    feedItems(feedId: string): Observable<Array<Feature>>;
    fetchAllFeeds(): Observable<Array<Feed>>;
    fetchFeed(feedId: string): Observable<FeedExpanded>;
    fetchService(serviceId: string): Observable<Service>;
    createService(service: {
        title: string;
        summary?: string;
        serviceType: string;
        config: any;
    }): Observable<Service>;
    fetchServices(): Observable<Array<Service>>;
    fetchServiceFeeds(serviceId: string): Observable<Array<Feed>>;
    fetchServiceType(serviceTypeId: string): Observable<ServiceType>;
    fetchTopics(serviceId: string): Observable<Array<FeedTopic>>;
    previewFeed(serviceId: string, topicId: string, feedSpec: Partial<Omit<FeedPost, 'service' | 'topic'>>, opts?: FeedPreviewOptions): Observable<FeedPreview>;
    fetchTopic(serviceId: string, topicId: string): Observable<FeedTopic>;
    fetchServiceTypes(): Observable<Array<ServiceType>>;
    createFeed(serviceId: string, topicId: string, feedConfiguration: any): Observable<FeedExpanded>;
    updateFeed(feed: Partial<Omit<FeedPost, 'id'>> & Pick<Feed, 'id'>): Observable<FeedExpanded>;
    deleteFeed(feed: Feed | FeedExpanded): Observable<{}>;
    deleteService(service: Service): Observable<{}>;
    fetchFeeds(eventId: number): Observable<Array<Feed>>;
    fetchFeedItems(event: any, feed: Feed): Observable<FeedContent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FeedService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FeedService>;
}

export { FeedService };
export type { Feed, FeedContent, FeedExpanded, FeedPost, FeedPreview, FeedPreviewOptions, FeedTopic, MapStyle, RegisteredMapStyle, Service, ServiceType, StyledFeature };
//# sourceMappingURL=index.d.ts.map
