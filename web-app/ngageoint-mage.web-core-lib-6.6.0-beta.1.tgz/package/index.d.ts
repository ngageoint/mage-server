import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class MageCoreLibModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MageCoreLibModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MageCoreLibModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MageCoreLibModule>;
}

export { MageCoreLibModule };
//# sourceMappingURL=index.d.ts.map
