import { DataSource, CollectionViewer } from '@angular/cdk/collections';
import { Observable } from 'rxjs';

interface PagingParameters {
    pageSize: number;
    pageIndex: number;
    includeTotalCount?: boolean | null;
}
interface PageOf<T> {
    pageSize: number;
    pageIndex: number;
    totalCount?: number | null;
    next?: PagingParameters | null;
    prev?: PagingParameters | null;
    items: T[];
}
declare const pageForItemIndex: (itemIndex: number, pageSize: number | PagingParameters) => number;
/**
 * Return the range of item indexes for the given page and page size.  The last
 * end portion of the range is exclusive, so when indexing an array the last
 * item of the page would have position `end - 1`.  This allows one to pass the
 * values to `Array.slice()`.
 * @param pageIndex
 * @param pageSize
 * @returns
 */
declare const itemRangeOfPage: {
    (pageIndex: number, pageSize: number): [number, number];
    (paging: PagingParameters): any;
};

/**
 * This class is an adaptation from the [Angular Material Guide](https://v8.material.angular.io/cdk/scrolling/overview), _"Specifying data" example_, also
 * available on [StackBlitz](https://stackblitz.com/angular/mrbkjagnnra?file=src%2Fapp%2Fcdk-virtual-scroll-data-source-example.ts).
 */
declare class PagingDataSource<T> extends DataSource<T> {
    private pageSize;
    private fetchPage;
    private data;
    private data$;
    private fetchedPages;
    private subscription;
    constructor(pageSize: number, fetchPage: (paging: PagingParameters) => Observable<PageOf<T>>);
    connect(collectionViewer: CollectionViewer): Observable<readonly T[]>;
    disconnect(): void;
    private pageForItemIndex;
    private fetch;
}

export { PagingDataSource, itemRangeOfPage, pageForItemIndex };
export type { PageOf, PagingParameters };
//# sourceMappingURL=index.d.ts.map
