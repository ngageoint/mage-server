import { HttpClient } from '@angular/common/http';
import * as i0 from '@angular/core';
import { InjectionToken, OnInit, OnChanges, AfterViewInit, SimpleChanges } from '@angular/core';
import { PagingParameters, PageOf } from '@ngageoint/mage.web-core-lib/paging';
import { Observable, Subject } from 'rxjs';
import * as i3 from '@angular/forms';
import { ControlValueAccessor } from '@angular/forms';
import * as i11 from '@ng-select/ng-select';
import { NgSelectComponent } from '@ng-select/ng-select';
import * as i2 from '@angular/common';
import * as i4 from '@angular/cdk/scrolling';
import * as i5 from '@angular/material/autocomplete';
import * as i6 from '@angular/material/dialog';
import * as i7 from '@angular/material/form-field';
import * as i8 from '@angular/material/input';
import * as i9 from '@angular/material/list';
import * as i10 from '@angular/material/select';

/**
 * This type represents a MAGE user account.  This is a base type that defines
 * the properties of a persisted user that the server returns from a read
 * operation, like a user query.  This type does not necessarily reflect the
 * properties the client would send to the server API for mutation operations.
 */
interface User {
    /**
     * Unique ID of the user account
     */
    id: string;
    /**
     * Unique name for this user account
     */
    username: string;
    displayName: string;
    /**
     * Whether an admin has activated this user account after initial sign-up
     */
    active: boolean;
    /**
     * Whether this account is enabled or diabled, typically by the manual action
     * of an administrator
     */
    enabled: boolean;
    /**
     * The authentication method for this user account
     */
    authentication: any;
    /**
     * ISO-8601 date string
     */
    createdAt: string;
    /**
     * ISO-8601 date string
     */
    lastUpdated: string;
    /**
     * The authorization role of this user account that defines the actions this
     * user account has permission to perform
     */
    role: string;
    email?: string;
    /**
     * URL of the image that identifies this user account in the user feed, etc.;
     * a profile picture
     */
    avatarUrl?: string;
    /**
     * Map marker icon info
     */
    icon?: UserIcon;
    /**
     * URL of the map marker icon image
     */
    iconUrl?: string;
    phones: UserPhone[];
    /**
     * List of events in which this user account has participated
     */
    recentEventIds: number[];
}
interface UserPhone {
    type: string;
    number: string;
}
interface UserIcon {
    /**
     * Hex color string beginning with `#`
     */
    color: string;
    /**
     * A standard media type, e.g., `image/png`
     */
    contentType: string;
    /**
     * Size in bytes of the icon image
     */
    size: number;
    text: string;
    /**
     * The source type of the icon
     */
    type: 'create' | 'upload' | 'none';
}

declare const USER_READ_BASE_URL = "/api/next-users";
declare class UserReadService {
    private webClient;
    constructor(webClient: HttpClient);
    search(which: UserSearchParams): Observable<PageOf<UserSearchResult>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserReadService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserReadService>;
}
interface UserSearchParams extends PagingParameters {
    term?: string | null | undefined;
}
type UserSearchResult = Pick<User, 'id' | 'username' | 'displayName' | 'email' | 'active' | 'enabled'> & {
    /**
     * A reduction of all the phone numbers to a single string
     */
    allPhones?: string | null | undefined;
};
declare const USER_READ_SERVICE: InjectionToken<UserReadService>;

declare class UserSelectComponent implements OnInit, OnChanges, AfterViewInit, ControlValueAccessor {
    private userService;
    readonly baseFindParams: Readonly<UserSearchParams>;
    readonly nextPageScrollThreshold = 15;
    readonly searchTermDebounceTime = 500;
    readonly trackByUserId: (x: User) => User['id'];
    get loading(): boolean;
    users: UserSearchResult[];
    totalCount: number;
    searchTerm$: Subject<string>;
    currentSearchTerm: string | null;
    userSelect: NgSelectComponent;
    private currentFetch;
    constructor(userService: UserReadService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    writeValue(x: User | null): void;
    registerOnChange(fn: (...args: any[]) => any): void;
    registerOnTouched(fn: (...args: any[]) => any): void;
    setDisabledState(isDisabled: boolean): void;
    onOpen(): void;
    onScroll({ end }: {
        start: number;
        end: number;
    }): void;
    onScrollToEnd(): void;
    fetchNextPage(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserSelectComponent, "mage-user-select", never, {}, {}, never, never, false, never>;
}

declare class MageUserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MageUserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MageUserModule, [typeof UserSelectComponent], [typeof i2.CommonModule, typeof i3.FormsModule, typeof i3.ReactiveFormsModule, typeof i4.ScrollingModule, typeof i5.MatAutocompleteModule, typeof i6.MatDialogModule, typeof i7.MatFormFieldModule, typeof i8.MatInputModule, typeof i9.MatListModule, typeof i10.MatSelectModule, typeof i11.NgSelectModule], [typeof UserSelectComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MageUserModule>;
}

export { MageUserModule, USER_READ_BASE_URL, USER_READ_SERVICE, UserReadService, UserSelectComponent };
export type { User, UserIcon, UserPhone, UserSearchParams, UserSearchResult };
//# sourceMappingURL=index.d.ts.map
