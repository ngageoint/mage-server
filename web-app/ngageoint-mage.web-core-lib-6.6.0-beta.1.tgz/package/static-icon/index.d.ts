import * as i0 from '@angular/core';
import { OnChanges, OnDestroy, SimpleChanges, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as i5 from '@angular/forms';
import { ControlValueAccessor, Validator, UntypedFormGroup, AbstractControl, ValidationErrors } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Observable } from 'rxjs';
import { PagingParameters, PageOf, PagingDataSource } from '@ngageoint/mage.web-core-lib/paging';
import * as i4 from '@angular/common';
import * as i6 from '@angular/material/card';
import * as i7 from '@ngageoint/mage.web-core-lib/common';
import * as i8 from '@angular/cdk/scrolling';

interface StaticIcon {
    id: string;
    sourceUrl: string;
    contentPath: string;
    title?: string;
    summary?: string;
    fileName?: string;
    tags?: string[];
}
interface RegisteredStaticIconReference {
    id: string;
    sourceUrl?: never;
}
interface SourceUrlStaticIconReference {
    sourceUrl: string;
    id?: never;
}
declare const contentPathOfIcon: (icon?: StaticIcon | RegisteredStaticIconReference | string | null | undefined) => string | undefined;
type StaticIconReference = RegisteredStaticIconReference | SourceUrlStaticIconReference;

interface IconFetch extends PagingParameters {
    searchText?: string;
}
declare class StaticIconService {
    private webClient;
    constructor(webClient: HttpClient);
    fetchIcons(fetch?: IconFetch): Observable<PageOf<StaticIcon>>;
    fetchIconById(id: string): Observable<StaticIcon | null>;
    fetchIconBySourceUrl(url: string): Observable<StaticIcon>;
    fetchIconByReference(ref: StaticIconReference): Observable<StaticIcon | null>;
    registerIconUrl(url: string): Observable<StaticIcon>;
    uploadIcon(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StaticIconService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StaticIconService>;
}

declare class StaticIconFormFieldComponent implements OnChanges, OnDestroy, ControlValueAccessor, Validator {
    private iconService;
    private httpClient;
    private sanitizer;
    iconRef: StaticIconReference;
    form: UntypedFormGroup;
    icon: StaticIcon | null;
    private onChange;
    private onValidatorChange;
    private onTouched;
    constructor(iconService: StaticIconService, httpClient: HttpClient, sanitizer: DomSanitizer);
    registerOnValidatorChange?(fn: () => void): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    onSelectIcon(): void;
    writeValue(iconRef: StaticIconReference): void;
    registerOnChange(fn: (x: StaticIconReference | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState?(isDisabled: boolean): void;
    validate(control: AbstractControl): ValidationErrors;
    private resolveIconRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<StaticIconFormFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StaticIconFormFieldComponent, "mage-static-icon-form-field", never, {}, {}, never, never, false, never>;
}

declare class StaticIconImgComponent implements OnInit, OnChanges {
    iconRef: RegisteredStaticIconReference | string | null;
    iconPath: string | null;
    constructor();
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StaticIconImgComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StaticIconImgComponent, "mage-static-icon-img", never, { "iconRef": { "alias": "iconRef"; "required": false; }; }, {}, never, never, false, never>;
}

interface StaticIconSelectItem {
    id: string;
    path: string;
    title: string;
    fileName: string;
}
declare class StaticIconSelectComponent implements OnInit {
    private iconService;
    icons: StaticIcon[] | null;
    dataSource: PagingDataSource<StaticIcon>;
    constructor(iconService: StaticIconService);
    ngOnInit(): void;
    onBrowseForUploadIcon(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StaticIconSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StaticIconSelectComponent, "static-icon-select", never, {}, {}, never, never, false, never>;
}

declare class StaticIconModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StaticIconModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StaticIconModule, [typeof StaticIconFormFieldComponent, typeof StaticIconImgComponent, typeof StaticIconSelectComponent], [typeof i4.CommonModule, typeof i5.FormsModule, typeof i5.ReactiveFormsModule, typeof i6.MatCardModule, typeof i7.MageCommonModule, typeof i8.ScrollingModule], [typeof StaticIconFormFieldComponent, typeof StaticIconImgComponent, typeof StaticIconSelectComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StaticIconModule>;
}

export { StaticIconFormFieldComponent, StaticIconImgComponent, StaticIconModule, StaticIconSelectComponent, StaticIconService, contentPathOfIcon };
export type { IconFetch, RegisteredStaticIconReference, SourceUrlStaticIconReference, StaticIcon, StaticIconReference, StaticIconSelectItem };
//# sourceMappingURL=index.d.ts.map
