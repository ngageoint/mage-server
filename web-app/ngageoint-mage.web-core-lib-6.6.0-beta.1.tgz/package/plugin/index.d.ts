import { Type } from '@angular/core';

interface PluginHooks {
    module: Type<unknown>;
    adminTab?: {
        title: string;
        icon?: {
            path: string;
        } | {
            matIconName: string;
        } | null | undefined;
        tabContentComponent: Type<unknown>;
    };
}

export type { PluginHooks };
//# sourceMappingURL=index.d.ts.map
