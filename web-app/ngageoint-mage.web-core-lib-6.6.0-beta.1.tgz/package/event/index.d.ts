import { InjectionToken } from '@angular/core';
import { PagingParameters } from '@ngageoint/mage.web-core-lib/paging';
import { Observable } from 'rxjs';

interface MageEvent {
    id: number;
    name: string;
    description: string;
    feedIds: string[];
}

interface EventReadService {
    find(which: EventReadParams): Observable<MageEvent[]>;
}
interface EventReadParams {
    page: PagingParameters;
}
declare const EVENT_READ_SERVICE: InjectionToken<EventReadService>;

export { EVENT_READ_SERVICE };
export type { EventReadParams, EventReadService, MageEvent };
//# sourceMappingURL=index.d.ts.map
