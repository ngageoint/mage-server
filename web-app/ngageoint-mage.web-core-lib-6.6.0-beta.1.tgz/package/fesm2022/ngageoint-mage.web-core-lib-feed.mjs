import * as i0 from '@angular/core';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import * as i1 from '@angular/common/http';

class FeedService {
    constructor(webClient) {
        this.webClient = webClient;
        // TODO: there is probably a better solution than maintaining this map here
        this._feeds = new BehaviorSubject([]);
        this.feeds$ = this._feeds.asObservable();
        this._feedItems = new Map();
    }
    feedItems(feedId) {
        return this._feedItems.get(feedId).asObservable();
    }
    fetchAllFeeds() {
        return this.webClient.get('/api/feeds/');
    }
    fetchFeed(feedId) {
        return this.webClient.get(`/api/feeds/${feedId}`);
    }
    fetchService(serviceId) {
        return this.webClient.get(`/api/feeds/services/${serviceId}`);
    }
    createService(service) {
        return this.webClient.post(`/api/feeds/services`, service);
    }
    fetchServices() {
        return this.webClient.get(`/api/feeds/services`);
    }
    fetchServiceFeeds(serviceId) {
        return this.webClient.get(`/api/feeds/services/${serviceId}/feeds`);
    }
    fetchServiceType(serviceTypeId) {
        return this.webClient.get(`/api/feeds/service_types/${serviceTypeId}`);
    }
    fetchTopics(serviceId) {
        return this.webClient.get(`/api/feeds/services/${serviceId}/topics`);
    }
    previewFeed(serviceId, topicId, feedSpec, opts) {
        opts = opts || {};
        const skipContentFetch = opts.skipContentFetch === true;
        return this.webClient.post(`/api/feeds/services/${serviceId}/topics/${topicId}/feed_preview?skip_content_fetch=${skipContentFetch}`, { feed: feedSpec });
    }
    fetchTopic(serviceId, topicId) {
        return this.webClient.get(`/api/feeds/services/${serviceId}/topics/${topicId}`);
    }
    fetchServiceTypes() {
        return this.webClient.get(`/api/feeds/service_types`);
    }
    createFeed(serviceId, topicId, feedConfiguration) {
        return this.webClient.post(`/api/feeds/services/${serviceId}/topics/${topicId}/feeds`, feedConfiguration);
    }
    updateFeed(feed) {
        return this.webClient.put(`/api/feeds/${feed.id}`, feed);
    }
    deleteFeed(feed) {
        return this.webClient.delete(`/api/feeds/${feed.id}`, { responseType: 'text' });
    }
    deleteService(service) {
        console.log('delete');
        return this.webClient.delete(`/api/feeds/services/${service.id}`, { responseType: 'text' });
    }
    fetchFeeds(eventId) {
        const subject = new Subject();
        this.webClient.get(`/api/events/${eventId}/feeds`).subscribe(feeds => {
            feeds.map(feed => {
                feed.id = feed.id.toString();
                return feed;
            });
            feeds.forEach(feed => {
                let feedItems = this._feedItems.get(feed.id);
                if (!feedItems) {
                    feedItems = new BehaviorSubject([]);
                    this._feedItems.set(feed.id, feedItems);
                }
            });
            subject.next(feeds);
            this._feeds.next(feeds);
        });
        return subject;
    }
    fetchFeedItems(event, feed) {
        const feedItems = this._feedItems.get(feed.id);
        return this.webClient.post(`/api/events/${event.id}/feeds/${feed.id}/content`, {}).pipe(map(content => {
            const features = content.items.features;
            features.forEach((feature) => {
                feature.id = String(feature.id);
                feature.properties = feature.properties || {};
            });
            feedItems.next(features);
            return content;
        }));
    }
    static { this.ɵfac = function FeedService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || FeedService)(i0.ɵɵinject(i1.HttpClient)); }; }
    static { this.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FeedService, factory: FeedService.ɵfac, providedIn: 'root' }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FeedService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], () => [{ type: i1.HttpClient }], null); })();

/**
 * Generated bundle index. Do not edit.
 */

export { FeedService };
//# sourceMappingURL=ngageoint-mage.web-core-lib-feed.mjs.map
