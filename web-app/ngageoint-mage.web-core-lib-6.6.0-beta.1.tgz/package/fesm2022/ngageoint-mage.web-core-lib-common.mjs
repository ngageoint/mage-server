import * as i0 from '@angular/core';
import { InjectionToken, Component, Inject, Input, NgModule } from '@angular/core';
import * as i1 from '@angular/common/http';
import * as i2 from '@angular/platform-browser';
import { CommonModule } from '@angular/common';

const selector = 'mage-xhr-img';
const OBJECT_URL_SERVICE = new InjectionToken(`${selector}.objectUrlService`);
/**
 * This component allows fetching images by `XMLHttpRequest` rather than the
 * browser's native mechanism.  These image requests are subject to HTTP
 * interceptors that can add authorization headers to the request instead of
 * using cache-defeating URL query parameters to set an auth token.  Applying
 * headers to the browser's native `img` requests is impossible, so a query
 * parameter is necessary for authorization, but adding the parameter to the
 * URL effectively bypasses the browser's caching mechanism when the auth token
 * changes for images that
 * should otherwise be subject to caching.
 *
 * The catch to fetching images by XHR is the response must be fetched as a
 * `Blob`.  The user then gets a browser-specific URL for the blob by
 * `URL.createObjectURL(blob)`, which can then be assigned to the `src`
 * attribute of an `img` tag.  These blob URLs must then be "revoked" by
 * `URL.revokeObjectURL(url)` in order to reclaim object URL's associated
 * resources.  See [Mozilla's docs](https://developer.mozilla.org/en-US/docs/Web/API/File/Using_files_from_web_applications#example_using_object_urls_to_display_images)
 * on the subject.
 *
 * To use the component, simply add the tag to a template and bind the `src`
 * attribute to the source URL of the desired image.
 * ```
 * <mage-xhr-img [src]="someComponent.imageUrlRequiresAuth"></mage-xhr-img>
 * ```
 * The component encapsulates the logic of creating and releasing the object
 * URLs for the image data, preventing memory leaks.
 */
class XhrImgComponent {
    constructor(objectUrlService, webClient, sanitizer) {
        this.objectUrlService = objectUrlService;
        this.webClient = webClient;
        this.sanitizer = sanitizer;
        this.sourceUrl = null;
        this.safeBlobUrl = null;
    }
    ngOnChanges(changes) {
        if (!changes.sourceUrl) {
            return;
        }
        if (changes.sourceUrl.isFirstChange() && !this.sourceUrl) {
            return;
        }
        this.disposeCurrent();
        if (!this.sourceUrl) {
            return;
        }
        this.subscription = this.webClient.get(this.sourceUrl, { responseType: 'blob' })
            .subscribe(x => {
            this.objectUrlService.revokeObjectURL(this.blobUrl);
            this.blobUrl = this.objectUrlService.createObjectURL(x);
            this.safeBlobUrl = this.sanitizer.bypassSecurityTrustUrl(this.blobUrl);
        });
    }
    ngOnDestroy() {
        this.disposeCurrent();
    }
    onImgLoad() {
        this.disposeCurrent();
    }
    disposeCurrent() {
        if (this.blobUrl) {
            this.objectUrlService.revokeObjectURL(this.blobUrl);
        }
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
        this.blobUrl = null;
    }
    static { this.ɵfac = function XhrImgComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || XhrImgComponent)(i0.ɵɵdirectiveInject(OBJECT_URL_SERVICE), i0.ɵɵdirectiveInject(i1.HttpClient), i0.ɵɵdirectiveInject(i2.DomSanitizer)); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: XhrImgComponent, selectors: [["mage-xhr-img"]], inputs: { sourceUrl: [0, "src", "sourceUrl"] }, standalone: false, features: [i0.ɵɵProvidersFeature([
                {
                    provide: OBJECT_URL_SERVICE,
                    useValue: URL
                }
            ]), i0.ɵɵNgOnChangesFeature], decls: 1, vars: 1, consts: [[3, "load"]], template: function XhrImgComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "img", 0);
            i0.ɵɵlistener("load", function XhrImgComponent_Template_img_load_0_listener() { return ctx.onImgLoad(); });
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵattribute("src", ctx.safeBlobUrl, i0.ɵɵsanitizeUrl);
        } }, styles: ["img[_ngcontent-%COMP%]{height:100%;width:100%}"] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(XhrImgComponent, [{
        type: Component,
        args: [{ selector: `${selector}`, template: `<img [attr.src]="safeBlobUrl" (load)="onImgLoad()"/>`, providers: [
                    {
                        provide: OBJECT_URL_SERVICE,
                        useValue: URL
                    }
                ], standalone: false, styles: ["img{height:100%;width:100%}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [OBJECT_URL_SERVICE]
            }] }, { type: i1.HttpClient }, { type: i2.DomSanitizer }], { sourceUrl: [{
            type: Input,
            args: ['src']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(XhrImgComponent, { className: "XhrImgComponent", filePath: "xhr-img.component.ts", lineNumber: 59 }); })();

class MageCommonModule {
    static { this.ɵfac = function MageCommonModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MageCommonModule)(); }; }
    static { this.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: MageCommonModule }); }
    static { this.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MageCommonModule, [{
        type: NgModule,
        args: [{
                imports: [
                    CommonModule
                ],
                declarations: [
                    XhrImgComponent
                ],
                exports: [
                    XhrImgComponent
                ]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(MageCommonModule, { declarations: [XhrImgComponent], imports: [CommonModule], exports: [XhrImgComponent] }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { MageCommonModule, OBJECT_URL_SERVICE, XhrImgComponent };
//# sourceMappingURL=ngageoint-mage.web-core-lib-common.mjs.map
