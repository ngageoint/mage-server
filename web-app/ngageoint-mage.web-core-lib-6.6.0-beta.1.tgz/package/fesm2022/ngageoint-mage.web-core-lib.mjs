import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

class MageCoreLibModule {
    static { this.ɵfac = function MageCoreLibModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MageCoreLibModule)(); }; }
    static { this.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: MageCoreLibModule }); }
    static { this.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MageCoreLibModule, [{
        type: NgModule,
        args: [{
                declarations: [],
                imports: [
                    CommonModule
                ]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(MageCoreLibModule, { imports: [CommonModule] }); })();

/*
 * Public API Surface of core-lib
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MageCoreLibModule };
//# sourceMappingURL=ngageoint-mage.web-core-lib.mjs.map
