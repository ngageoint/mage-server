import * as i0 from '@angular/core';
import { Injectable, InjectionToken, forwardRef, Component, ViewChild, NgModule } from '@angular/core';
import * as i1 from '@angular/common/http';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatSelectModule } from '@angular/material/select';
import * as i2 from '@ng-select/ng-select';
import { NgSelectComponent, NgSelectModule } from '@ng-select/ng-select';
import { pageForItemIndex } from '@ngageoint/mage.web-core-lib/paging';
import { Subject } from 'rxjs';
import { distinctUntilChanged, debounceTime } from 'rxjs/operators';

const USER_READ_BASE_URL = '/api/next-users';
class UserReadService {
    constructor(webClient) {
        this.webClient = webClient;
    }
    search(which) {
        const queryParams = {
            page_size: String(which.pageSize),
            page: String(which.pageIndex),
        };
        if (typeof which.term === 'string') {
            queryParams.term = which.term;
        }
        if (typeof which.includeTotalCount === 'boolean') {
            queryParams.total = which.includeTotalCount ? 'true' : 'false';
        }
        return this.webClient.get(`${USER_READ_BASE_URL}/search`, {
            params: queryParams
        });
    }
    static { this.ɵfac = function UserReadService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || UserReadService)(i0.ɵɵinject(i1.HttpClient)); }; }
    static { this.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: UserReadService, factory: UserReadService.ɵfac, providedIn: 'root' }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(UserReadService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], () => [{ type: i1.HttpClient }], null); })();
const USER_READ_SERVICE = new InjectionToken('UserReadService');

function UserSelectComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "small", 3);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1("", ctx_r0.totalCount, " matching users");
} }
function UserSelectComponent_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 4)(1, "p", 5);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "p", 6);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "p", 6);
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const user_r2 = ctx.item;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate2("", user_r2.displayName, " (", user_r2.username, ")");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(user_r2.email || "[no email]");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(user_r2.allPhones || "[no phone]");
} }
class UserSelectComponent {
    get loading() {
        return !!this.currentFetch && !this.currentFetch.closed;
    }
    constructor(userService) {
        this.userService = userService;
        this.baseFindParams = Object.freeze({
            pageSize: 100,
            pageIndex: 0,
            term: null
        });
        this.nextPageScrollThreshold = 15;
        this.searchTermDebounceTime = 500;
        this.trackByUserId = x => x.id;
        this.users = [];
        this.totalCount = 0;
        this.searchTerm$ = new Subject();
        this.currentSearchTerm = null;
        this.currentFetch = null;
    }
    ngOnInit() {
        this.searchTerm$.pipe(distinctUntilChanged(), debounceTime(this.searchTermDebounceTime))
            .subscribe(x => {
            this.currentSearchTerm = x;
            this.users = [];
            this.totalCount = 0;
            if (this.currentFetch) {
                this.currentFetch.unsubscribe();
                this.currentFetch = null;
            }
            this.fetchNextPage();
        });
    }
    ngOnChanges(changes) {
    }
    ngAfterViewInit() {
    }
    writeValue(x) {
        this.userSelect.writeValue(x);
    }
    registerOnChange(fn) {
        this.userSelect.registerOnChange(fn);
    }
    registerOnTouched(fn) {
        this.userSelect.registerOnTouched(fn);
    }
    setDisabledState(isDisabled) {
        this.userSelect.setDisabledState(isDisabled);
    }
    onOpen() {
        if (this.users.length === 0) {
            this.fetchNextPage();
        }
    }
    onScroll({ end }) {
        if (end < this.users.length - this.nextPageScrollThreshold || this.users.length === this.totalCount) {
            return;
        }
        this.fetchNextPage();
    }
    onScrollToEnd() {
    }
    fetchNextPage() {
        if (this.currentFetch) {
            if (this.currentFetch.closed) {
                this.currentFetch = null;
            }
            else {
                return;
            }
        }
        const nextPage = pageForItemIndex(this.users.length, this.baseFindParams.pageSize);
        const findParams = {
            ...this.baseFindParams,
            pageIndex: nextPage
        };
        if (this.currentSearchTerm) {
            findParams.term = this.currentSearchTerm;
        }
        this.currentFetch = this.userService.search(findParams).subscribe(page => {
            this.users = this.users.concat(page.items);
            if (typeof page.totalCount === 'number') {
                this.totalCount = page.totalCount;
            }
        });
    }
    static { this.ɵfac = function UserSelectComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || UserSelectComponent)(i0.ɵɵdirectiveInject(UserReadService)); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: UserSelectComponent, selectors: [["mage-user-select"]], viewQuery: function UserSelectComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(NgSelectComponent, 7);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.userSelect = _t.first);
        } }, standalone: false, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    multi: true,
                    useExisting: forwardRef(() => UserSelectComponent)
                }
            ]), i0.ɵɵNgOnChangesFeature], decls: 3, vars: 5, consts: [["appendTo", "body", "placeholder", "Choose a user", "bindLabel", "displayName", 3, "open", "scroll", "scrollToEnd", "items", "typeahead", "virtualScroll", "loading", "trackByFn"], ["ng-header-tmp", ""], ["ng-option-tmp", "", 1, "user-option"], [1, "form-text", "text-muted"], [1, "user-option"], [1, "user-option__line", "primary"], [1, "user-option__line", "detail"]], template: function UserSelectComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "ng-select", 0);
            i0.ɵɵlistener("open", function UserSelectComponent_Template_ng_select_open_0_listener() { return ctx.onOpen(); })("scroll", function UserSelectComponent_Template_ng_select_scroll_0_listener($event) { return ctx.onScroll($event); })("scrollToEnd", function UserSelectComponent_Template_ng_select_scrollToEnd_0_listener() { return ctx.onScrollToEnd(); });
            i0.ɵɵtemplate(1, UserSelectComponent_ng_template_1_Template, 2, 1, "ng-template", 1)(2, UserSelectComponent_ng_template_2_Template, 7, 4, "ng-template", 2);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵproperty("items", ctx.users)("typeahead", ctx.searchTerm$)("virtualScroll", true)("loading", ctx.loading)("trackByFn", ctx.trackByUserId);
        } }, dependencies: [i2.NgSelectComponent, i2.NgOptionTemplateDirective, i2.NgHeaderTemplateDirective], styles: [".user-option[_ngcontent-%COMP%]{margin:.85em 0}.user-option[_ngcontent-%COMP%] > .user-option__line[_ngcontent-%COMP%]{margin:0 0 .6em;padding:0;line-height:1em;overflow:hidden;text-overflow:ellipsis}.user-option[_ngcontent-%COMP%] > .user-option__line.primary[_ngcontent-%COMP%]{font-size:1em}.user-option[_ngcontent-%COMP%] > .user-option__line.detail[_ngcontent-%COMP%]{font-size:.85em;opacity:.75}"] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(UserSelectComponent, [{
        type: Component,
        args: [{ selector: 'mage-user-select', providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        multi: true,
                        useExisting: forwardRef(() => UserSelectComponent)
                    }
                ], standalone: false, template: "<ng-select [items]=\"users\"\n  [typeahead]=\"searchTerm$\"\n  [virtualScroll]=\"true\"\n  [loading]=\"loading\"\n  [trackByFn]=\"trackByUserId\"\n  appendTo=\"body\"\n  placeholder=\"Choose a user\"\n  bindLabel=\"displayName\"\n  (open)=\"onOpen()\"\n  (scroll)=\"onScroll($event)\"\n  (scrollToEnd)=\"onScrollToEnd()\"\n  >\n  <ng-template ng-header-tmp>\n    <small class=\"form-text text-muted\">{{totalCount}} matching users</small>\n  </ng-template>\n  <ng-template class=\"user-option\" ng-option-tmp let-user=\"item\" let-index=\"index\">\n    <div class=\"user-option\">\n      <p class=\"user-option__line primary\">{{user.displayName}} ({{user.username}})</p>\n      <p class=\"user-option__line detail\">{{user.email || '[no email]'}}</p>\n      <p class=\"user-option__line detail\">{{user.allPhones || '[no phone]'}}</p>\n    </div>\n  </ng-template>\n</ng-select>\n", styles: [".user-option{margin:.85em 0}.user-option>.user-option__line{margin:0 0 .6em;padding:0;line-height:1em;overflow:hidden;text-overflow:ellipsis}.user-option>.user-option__line.primary{font-size:1em}.user-option>.user-option__line.detail{font-size:.85em;opacity:.75}\n"] }]
    }], () => [{ type: UserReadService }], { userSelect: [{
            type: ViewChild,
            args: [NgSelectComponent, { static: true }]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(UserSelectComponent, { className: "UserSelectComponent", filePath: "user-select/user-select.component.ts", lineNumber: 26 }); })();

class MageUserModule {
    static { this.ɵfac = function MageUserModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MageUserModule)(); }; }
    static { this.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: MageUserModule }); }
    static { this.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            ScrollingModule,
            MatAutocompleteModule,
            MatDialogModule,
            MatFormFieldModule,
            MatInputModule,
            MatListModule,
            MatSelectModule,
            NgSelectModule] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MageUserModule, [{
        type: NgModule,
        args: [{
                imports: [
                    CommonModule,
                    FormsModule,
                    ReactiveFormsModule,
                    ScrollingModule,
                    MatAutocompleteModule,
                    MatDialogModule,
                    MatFormFieldModule,
                    MatInputModule,
                    MatListModule,
                    MatSelectModule,
                    NgSelectModule,
                ],
                declarations: [
                    UserSelectComponent
                ],
                exports: [
                    UserSelectComponent
                ]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(MageUserModule, { declarations: [UserSelectComponent], imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        ScrollingModule,
        MatAutocompleteModule,
        MatDialogModule,
        MatFormFieldModule,
        MatInputModule,
        MatListModule,
        MatSelectModule,
        NgSelectModule], exports: [UserSelectComponent] }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { MageUserModule, USER_READ_BASE_URL, USER_READ_SERVICE, UserReadService, UserSelectComponent };
//# sourceMappingURL=ngageoint-mage.web-core-lib-user.mjs.map
