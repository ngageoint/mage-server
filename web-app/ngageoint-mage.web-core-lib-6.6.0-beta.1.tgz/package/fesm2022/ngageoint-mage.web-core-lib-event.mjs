import { InjectionToken } from '@angular/core';

const EVENT_READ_SERVICE = new InjectionToken('EventReadService');

/**
 * Generated bundle index. Do not edit.
 */

export { EVENT_READ_SERVICE };
//# sourceMappingURL=ngageoint-mage.web-core-lib-event.mjs.map
