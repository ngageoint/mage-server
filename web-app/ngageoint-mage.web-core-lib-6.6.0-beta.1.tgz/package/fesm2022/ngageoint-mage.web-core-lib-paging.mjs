import { DataSource } from '@angular/cdk/collections';
import { BehaviorSubject, Subscription } from 'rxjs';

const pageForItemIndex = (itemIndex, pageSize) => {
    if (typeof pageSize === 'object') {
        pageSize = pageSize.pageSize;
    }
    return Math.floor(itemIndex / pageSize);
};
/**
 * Return the range of item indexes for the given page and page size.  The last
 * end portion of the range is exclusive, so when indexing an array the last
 * item of the page would have position `end - 1`.  This allows one to pass the
 * values to `Array.slice()`.
 * @param pageIndex
 * @param pageSize
 * @returns
 */
const itemRangeOfPage = (pageIndex, pageSize) => {
    if (typeof pageIndex === 'object') {
        pageSize = pageIndex.pageSize;
        pageIndex = pageIndex.pageIndex;
    }
    const start = pageSize * pageIndex;
    const end = start + pageSize;
    return [start, end];
};

/**
 * This class is an adaptation from the [Angular Material Guide](https://v8.material.angular.io/cdk/scrolling/overview), _"Specifying data" example_, also
 * available on [StackBlitz](https://stackblitz.com/angular/mrbkjagnnra?file=src%2Fapp%2Fcdk-virtual-scroll-data-source-example.ts).
 */
class PagingDataSource extends DataSource {
    constructor(pageSize, fetchPage) {
        super();
        this.pageSize = pageSize;
        this.fetchPage = fetchPage;
        this.data = null;
        this.data$ = new BehaviorSubject([]);
        this.fetchedPages = new Set();
        this.subscription = new Subscription();
    }
    connect(collectionViewer) {
        this.subscription.add(collectionViewer.viewChange.subscribe(range => {
            const startPage = this.pageForItemIndex(range.start);
            const endPage = this.pageForItemIndex(range.end - 1);
            for (let page = startPage; page <= endPage; page++) {
                this.fetch(page);
            }
        }));
        return this.data$;
    }
    disconnect() {
        this.subscription.unsubscribe();
    }
    pageForItemIndex(index) {
        return pageForItemIndex(index, this.pageSize);
    }
    fetch(pageIndex) {
        if (this.fetchedPages.has(pageIndex)) {
            return;
        }
        this.fetchedPages.add(pageIndex);
        const includeTotalCount = !this.data;
        this.fetchPage({ pageSize: this.pageSize, pageIndex: pageIndex, includeTotalCount }).subscribe(page => {
            if (!this.data) {
                if (typeof (page.totalCount) !== 'number') {
                    throw new Error('data is null and no total count is available to inform allocation');
                }
                this.data = Array.from({ length: page.totalCount });
            }
            this.data.splice(pageIndex * this.pageSize, this.pageSize, ...page.items);
            this.data$.next(this.data);
        });
    }
}

/**
 * Generated bundle index. Do not edit.
 */

export { PagingDataSource, itemRangeOfPage, pageForItemIndex };
//# sourceMappingURL=ngageoint-mage.web-core-lib-paging.mjs.map
