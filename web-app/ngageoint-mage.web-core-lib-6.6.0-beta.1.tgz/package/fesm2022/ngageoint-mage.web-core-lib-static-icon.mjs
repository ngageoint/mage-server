import * as i3$1 from '@angular/cdk/scrolling';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, Component, Input, NgModule } from '@angular/core';
import * as i4 from '@angular/forms';
import { UntypedFormGroup, UntypedFormControl, Validators, NG_VALUE_ACCESSOR, NG_VALIDATORS, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i2 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i5 from '@ngageoint/mage.web-core-lib/common';
import { MageCommonModule } from '@ngageoint/mage.web-core-lib/common';
import * as i1 from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as i3 from '@angular/platform-browser';
import { PagingDataSource } from '@ngageoint/mage.web-core-lib/paging';

const contentPathOfIcon = (icon) => {
    if (!icon) {
        return;
    }
    if (typeof icon !== 'string') {
        icon = icon.id;
    }
    return `/api/icons/${icon}/content`;
};

class StaticIconService {
    constructor(webClient) {
        this.webClient = webClient;
    }
    fetchIcons(fetch) {
        const now = Date.now();
        const results = new Observable(observer => {
            const icons = [];
            let remaining = 100;
            while (remaining--) {
                const id = now - remaining;
                icons.unshift({
                    id: String(id),
                    title: `Icon ${id}`,
                    fileName: `icon-${id}.png`,
                    sourceUrl: `https://test.mage/${id}.png`,
                    contentPath: `/icons/${id}/content`
                });
            }
            setTimeout(() => {
                observer.next({
                    pageSize: 100,
                    pageIndex: 0,
                    totalCount: 100,
                    items: icons
                });
                observer.complete();
            }, 0);
            return {
                unsubscribe() { }
            };
        });
        return results;
    }
    fetchIconById(id) {
        return this.webClient.get(`/api/icons/${id}`).pipe(catchError((err, caught) => {
            // TODO: this is probably better practice to insulate app layer from
            // http errors
            // if (err instanceof HttpErrorResponse) {
            //   if (err.status === 404) {
            //     return null
            //   }
            // }
            return throwError(err);
        }));
    }
    fetchIconBySourceUrl(url) {
        return this.webClient.get(`/api/icons`, {
            params: new HttpParams().set('source_url', url)
        });
    }
    fetchIconByReference(ref) {
        if (ref.id) {
            return this.fetchIconById(ref.id);
        }
        else if (ref.sourceUrl) {
            return this.fetchIconBySourceUrl(ref.sourceUrl);
        }
        throw new Error('no icon id or source url');
    }
    registerIconUrl(url) {
        throw new Error('unimplemented');
    }
    uploadIcon() {
        throw new Error('unimplemented');
    }
    static { this.ɵfac = function StaticIconService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || StaticIconService)(i0.ɵɵinject(i1.HttpClient)); }; }
    static { this.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: StaticIconService, factory: StaticIconService.ɵfac, providedIn: 'root' }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StaticIconService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], () => [{ type: i1.HttpClient }], null); })();

class StaticIconFormFieldComponent {
    constructor(iconService, httpClient, sanitizer) {
        this.iconService = iconService;
        this.httpClient = httpClient;
        this.sanitizer = sanitizer;
        this.iconRef = null;
        this.form = new UntypedFormGroup({
            iconRefToken: new UntypedFormControl(null),
            iconRefType: new UntypedFormControl(null, Validators.required)
        });
        this.onChange = (iconRef) => { };
        this.onValidatorChange = () => { };
        this.onTouched = () => { };
        this.form.valueChanges.subscribe((x) => {
            this.iconRef = iconRefForFormValue(x);
            this.onChange(this.iconRef);
        });
    }
    registerOnValidatorChange(fn) {
        this.onValidatorChange = fn;
    }
    ngOnChanges(changes) { }
    ngOnDestroy() { }
    onSelectIcon() { }
    writeValue(iconRef) {
        this.iconRef = iconRef;
        const formValue = formValueForIconRef(iconRef);
        this.form.setValue(formValue, { emitEvent: false });
        this.resolveIconRef();
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        if (isDisabled) {
            this.form.disable();
        }
        else {
            this.form.enable();
        }
    }
    validate(control) {
        return this.form.errors;
    }
    resolveIconRef() {
        if (!this.iconRef) {
            this.icon = null;
            return;
        }
        this.iconService.fetchIconByReference(this.iconRef).subscribe(x => {
            this.icon = x;
            if (!this.icon) {
                return;
            }
        });
    }
    static { this.ɵfac = function StaticIconFormFieldComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || StaticIconFormFieldComponent)(i0.ɵɵdirectiveInject(StaticIconService), i0.ɵɵdirectiveInject(i1.HttpClient), i0.ɵɵdirectiveInject(i3.DomSanitizer)); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: StaticIconFormFieldComponent, selectors: [["mage-static-icon-form-field"]], standalone: false, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    multi: true,
                    useExisting: StaticIconFormFieldComponent
                },
                {
                    provide: NG_VALIDATORS,
                    multi: true,
                    useExisting: StaticIconFormFieldComponent
                },
            ]), i0.ɵɵNgOnChangesFeature], decls: 4, vars: 2, consts: [[3, "formGroup"], [1, "icon-image", 3, "src"], ["type", "hidden", "formControlName", "iconRefType"], ["type", "hidden", "formControlName", "iconRefToken"]], template: function StaticIconFormFieldComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵelement(1, "mage-xhr-img", 1)(2, "input", 2)(3, "input", 3);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵproperty("formGroup", ctx.form);
            i0.ɵɵadvance();
            i0.ɵɵproperty("src", ctx.icon == null ? null : ctx.icon.contentPath);
        } }, dependencies: [i4.DefaultValueAccessor, i4.NgControlStatus, i4.NgControlStatusGroup, i4.FormGroupDirective, i4.FormControlName, i5.XhrImgComponent], styles: [".icon-image[_ngcontent-%COMP%]{display:block;height:3em;width:3em}"] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StaticIconFormFieldComponent, [{
        type: Component,
        args: [{ selector: 'mage-static-icon-form-field', providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        multi: true,
                        useExisting: StaticIconFormFieldComponent
                    },
                    {
                        provide: NG_VALIDATORS,
                        multi: true,
                        useExisting: StaticIconFormFieldComponent
                    },
                ], standalone: false, template: "<div [formGroup]=\"form\">\n  <mage-xhr-img class=\"icon-image\" [src]=\"icon?.contentPath\"></mage-xhr-img>\n  <input type=\"hidden\" formControlName=\"iconRefType\"/>\n  <input type=\"hidden\" formControlName=\"iconRefToken\"/>\n</div>", styles: [".icon-image{display:block;height:3em;width:3em}\n"] }]
    }], () => [{ type: StaticIconService }, { type: i1.HttpClient }, { type: i3.DomSanitizer }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(StaticIconFormFieldComponent, { className: "StaticIconFormFieldComponent", filePath: "static-icon-form-field/static-icon-form-field.component.ts", lineNumber: 27 }); })();
var IconRefType;
(function (IconRefType) {
    IconRefType["Registered"] = "id";
    IconRefType["SourceUrl"] = "sourceUrl";
})(IconRefType || (IconRefType = {}));
function iconRefForFormValue(x) {
    if (!x.iconRefType) {
        return null;
    }
    switch (x.iconRefType) {
        case IconRefType.Registered:
            return { [IconRefType.Registered]: x.iconRefToken };
        case IconRefType.SourceUrl:
            return { [IconRefType.SourceUrl]: x.iconRefToken };
        default:
            throw new Error('invalid icon ref type: ' + x.iconRefToken);
    }
}
function formValueForIconRef(x) {
    if (!x) {
        return {
            iconRefType: null,
            iconRefToken: null
        };
    }
    let iconRefType = null;
    let iconRefToken = null;
    if (x.hasOwnProperty(IconRefType.Registered)) {
        iconRefType = IconRefType.Registered || null;
        iconRefToken = x[IconRefType.Registered] || null;
    }
    else if (x.hasOwnProperty(IconRefType.SourceUrl)) {
        iconRefType = IconRefType.SourceUrl || null;
        iconRefToken = x[IconRefType.SourceUrl] || null;
    }
    return {
        iconRefType,
        iconRefToken
    };
}

class StaticIconImgComponent {
    constructor() { }
    ngOnInit() {
    }
    ngOnChanges(changes) {
        if (changes.iconRef) {
            if (this.iconRef) {
                this.iconPath = contentPathOfIcon(this.iconRef);
            }
            else {
                this.iconPath = null;
            }
        }
    }
    static { this.ɵfac = function StaticIconImgComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || StaticIconImgComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: StaticIconImgComponent, selectors: [["mage-static-icon-img"]], inputs: { iconRef: "iconRef" }, standalone: false, features: [i0.ɵɵNgOnChangesFeature], decls: 1, vars: 1, consts: [[3, "src"]], template: function StaticIconImgComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelement(0, "mage-xhr-img", 0);
        } if (rf & 2) {
            i0.ɵɵproperty("src", ctx.iconPath);
        } }, dependencies: [i5.XhrImgComponent], encapsulation: 2 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StaticIconImgComponent, [{
        type: Component,
        args: [{
                selector: 'mage-static-icon-img',
                template: `<mage-xhr-img [src]="iconPath"></mage-xhr-img>`,
                standalone: false
            }]
    }], () => [], { iconRef: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(StaticIconImgComponent, { className: "StaticIconImgComponent", filePath: "static-icon-img/static-icon-img.component.ts", lineNumber: 9 }); })();

function StaticIconSelectComponent_mat_card_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card", 3)(1, "mat-card-header")(2, "mat-card-title");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()();
    i0.ɵɵelement(4, "img", 4);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const icon_r1 = ctx.$implicit;
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(icon_r1.title);
    i0.ɵɵadvance();
    i0.ɵɵproperty("src", icon_r1.path, i0.ɵɵsanitizeUrl);
} }
class StaticIconSelectComponent {
    constructor(iconService) {
        this.iconService = iconService;
        this.icons = null;
        this.dataSource = new PagingDataSource(250, (paging) => {
            return this.iconService.fetchIcons(paging);
        });
    }
    ngOnInit() {
        this.iconService.fetchIcons().subscribe(x => {
            this.icons = x.items;
        });
    }
    onBrowseForUploadIcon() {
        throw new Error('unimplemented');
    }
    static { this.ɵfac = function StaticIconSelectComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || StaticIconSelectComponent)(i0.ɵɵdirectiveInject(StaticIconService)); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: StaticIconSelectComponent, selectors: [["static-icon-select"]], standalone: false, decls: 3, vars: 2, consts: [[1, "icon-select"], [3, "itemSize"], ["class", "icon-select-item", 4, "cdkVirtualFor", "cdkVirtualForOf"], [1, "icon-select-item"], ["mat-card-img", "", 3, "src"]], template: function StaticIconSelectComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "cdk-virtual-scroll-viewport", 1);
            i0.ɵɵtemplate(2, StaticIconSelectComponent_mat_card_2_Template, 5, 2, "mat-card", 2);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("itemSize", 40);
            i0.ɵɵadvance();
            i0.ɵɵproperty("cdkVirtualForOf", ctx.icons);
        } }, dependencies: [i2.MatCard, i2.MatCardHeader, i2.MatCardTitle, i3$1.CdkFixedSizeVirtualScroll, i3$1.CdkVirtualForOf, i3$1.CdkVirtualScrollViewport], styles: ["virtual-scroll[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(3,33%);grid-auto-rows:min-content;grid-gap:0;justify-content:center;gap:0}"] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StaticIconSelectComponent, [{
        type: Component,
        args: [{ selector: 'static-icon-select', standalone: false, template: "<div class=\"icon-select\">\n  <cdk-virtual-scroll-viewport [itemSize]=\"40\">\n    <mat-card *cdkVirtualFor=\"let icon of icons\" class=icon-select-item>\n      <mat-card-header>\n        <mat-card-title>{{icon.title}}</mat-card-title>\n      </mat-card-header>\n      <img mat-card-img [src]=\"icon.path\" />\n    </mat-card>\n  </cdk-virtual-scroll-viewport>\n</div>\n<!--\n  <button mat-button class=\"add__button\" type=\"button\" color=\"primary\" (click)=\"file.click()\">\n    Upload Icon\n  </button>\n  <input [hidden]=\"true\" type=\"file\" #file multiple (change)=\"onAttachmentFile($event)\">\n-->", styles: ["virtual-scroll{display:grid;grid-template-columns:repeat(3,33%);grid-auto-rows:min-content;grid-gap:0;justify-content:center;gap:0}\n"] }]
    }], () => [{ type: StaticIconService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(StaticIconSelectComponent, { className: "StaticIconSelectComponent", filePath: "static-icon-select/static-icon-select.component.ts", lineNumber: 19 }); })();

class StaticIconModule {
    static { this.ɵfac = function StaticIconModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || StaticIconModule)(); }; }
    static { this.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: StaticIconModule }); }
    static { this.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            MatCardModule,
            MageCommonModule,
            ScrollingModule] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StaticIconModule, [{
        type: NgModule,
        args: [{
                imports: [
                    CommonModule,
                    FormsModule,
                    ReactiveFormsModule,
                    MatCardModule,
                    MageCommonModule,
                    ScrollingModule
                ],
                declarations: [
                    StaticIconFormFieldComponent,
                    StaticIconImgComponent,
                    StaticIconSelectComponent,
                ],
                exports: [
                    StaticIconFormFieldComponent,
                    StaticIconImgComponent,
                    StaticIconSelectComponent,
                ]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(StaticIconModule, { declarations: [StaticIconFormFieldComponent,
        StaticIconImgComponent,
        StaticIconSelectComponent], imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatCardModule,
        MageCommonModule,
        ScrollingModule], exports: [StaticIconFormFieldComponent,
        StaticIconImgComponent,
        StaticIconSelectComponent] }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { StaticIconFormFieldComponent, StaticIconImgComponent, StaticIconModule, StaticIconSelectComponent, StaticIconService, contentPathOfIcon };
//# sourceMappingURL=ngageoint-mage.web-core-lib-static-icon.mjs.map
