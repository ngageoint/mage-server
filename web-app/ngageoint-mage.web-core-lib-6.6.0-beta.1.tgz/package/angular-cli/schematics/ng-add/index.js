"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ngAdd = ngAdd;
/**
 * Return an identity rule that leaves the workspace tree unchanged, as there
 * are no default artifacts to add on installation.  However, an ng-add
 * schematic is necessary to support the `"ng-add"` package.json entry which
 * tells `ng-add` to add the lib to `"devDependencies"`.
 */
function ngAdd() {
    return tree => tree;
}
//# sourceMappingURL=index.js.map