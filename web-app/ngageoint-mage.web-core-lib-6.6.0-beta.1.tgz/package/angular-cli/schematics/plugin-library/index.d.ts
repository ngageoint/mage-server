import { Rule } from '@angular-devkit/schematics';
import { Schema as BaseLibraryOptions } from '@schematics/angular/library/schema';
export declare function mageWebPluginLibrary(options: PluginLibraryOptions): Rule;
export interface PluginLibraryOptions extends BaseLibraryOptions {
}
