"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mageWebPluginLibrary = mageWebPluginLibrary;
const schematics_1 = require("@angular-devkit/schematics");
const workspace_1 = require("@schematics/angular/utility/workspace");
const ast_utils_1 = require("@schematics/angular/utility/ast-utils");
const change_1 = require("@schematics/angular/utility/change");
const ts = require("@schematics/angular/third_party/github.com/Microsoft/TypeScript/lib/typescript");
const semver_1 = require("semver");
function addPluginHookToEntryPoint(options) {
    const entryFile = options.entryFile;
    if (!entryFile) {
        throw new schematics_1.SchematicsException('missing entryFile');
    }
    return async (tree, _context) => {
        const workspace = await (0, workspace_1.getWorkspace)(tree);
        const project = workspace.projects.get(options.name);
        if (!project) {
            throw new schematics_1.SchematicsException(`project not found in workspace: ${project}`);
        }
        const libDirPath = `${project.sourceRoot}/lib`;
        const libDir = tree.getDir(libDirPath);
        const module = findLibraryNgModule(tree, libDir);
        const moduleClassName = module.classDecl.name?.text;
        const component = findLibraryComponent(tree, libDir);
        const componentClassName = component.classDecl.name?.text;
        const entryFilePath = `${project.sourceRoot}/${entryFile}.ts`;
        const entryFileText = tree.readText(entryFilePath);
        const entrySource = ts.createSourceFile(entryFilePath, entryFileText, ts.ScriptTarget.Latest, true);
        const importCoreChange = (0, ast_utils_1.insertImport)(entrySource, entryFilePath, 'PluginHooks', '@ngageoint/mage.web-core-lib/plugin');
        const importModuleChange = moduleClassName ? (0, ast_utils_1.insertImport)(entrySource, entryFilePath, moduleClassName, `./lib/${module.sourceFile.fileName.slice(0, -3)}`) : new change_1.NoopChange();
        const importComponentChange = componentClassName ? (0, ast_utils_1.insertImport)(entrySource, entryFilePath, componentClassName, `./lib/${component.sourceFile.fileName.slice(0, -3)}`) : new change_1.NoopChange();
        const packageJson = tree.readJson(`${project.root}/package.json`);
        const packageName = packageJson.name;
        const pluginExport = `
export const MAGE_WEB_HOOKS: PluginHooks = {
  module: ${moduleClassName},
  adminTab: {
    title: '${packageName}',
    tabContentComponent: ${componentClassName},
  }
}
`;
        const exportNodes = (0, ast_utils_1.findNodes)(entrySource, ((x) => {
            return [
                ts.SyntaxKind.ExportAssignment,
                ts.SyntaxKind.ExportDeclaration,
                ts.SyntaxKind.ExportSpecifier,
                ts.SyntaxKind.NamedExports,
            ].includes(x.kind);
        }))
            .sort((a, b) => a.getStart() - b.getStart());
        const pluginExportChange = (0, ast_utils_1.insertAfterLastOccurrence)(exportNodes, pluginExport, entryFilePath, entrySource.end);
        const edit = tree.beginUpdate(entryFilePath);
        (0, change_1.applyToUpdateRecorder)(edit, [importCoreChange, importModuleChange, importComponentChange, pluginExportChange].filter(x => !!x));
        tree.commitUpdate(edit);
    };
}
function findLibraryNgModule(tree, baseDir) {
    const fileName = baseDir.subfiles.find(x => /\.module\.ts$/.test(x)) || '';
    const filePath = `${baseDir.path}/${fileName}`;
    const fileText = tree.readText(filePath);
    const source = ts.createSourceFile(fileName, fileText, ts.ScriptTarget.Latest, true);
    const classDecl = (0, ast_utils_1.findNodes)(source, ts.SyntaxKind.ClassDeclaration)[0];
    return { sourceFile: source, classDecl: classDecl };
}
function findLibraryComponent(tree, baseDir) {
    const fileName = baseDir.subfiles.find(x => /\.component\.ts$/.test(x)) || '';
    const filePath = `${baseDir.path}/${fileName}`;
    const fileText = tree.readText(filePath);
    const source = ts.createSourceFile(fileName, fileText, ts.ScriptTarget.Latest, true);
    const classDecl = (0, ast_utils_1.findNodes)(source, ts.SyntaxKind.ClassDeclaration)[0];
    return { sourceFile: source, classDecl: classDecl };
}
function useCustomBuilder(options) {
    return (0, workspace_1.updateWorkspace)(workspace => {
        const projName = options.name;
        const project = workspace.projects.get(projName);
        if (!project) {
            throw new schematics_1.SchematicsException(`project not found in workspace: ${projName}`);
        }
        const target = project.targets.get('build');
        project.targets.set('build', {
            ...target,
            builder: '@ngageoint/mage.web-core-lib:amd'
        });
        workspace.projects.set(projName, project);
    });
}
function addCorePeerDependency(options) {
    return async (tree, _context) => {
        const corePkg = require('@ngageoint/mage.web-core-lib/package.json');
        const coreVersion = (0, semver_1.parse)(corePkg.version);
        const coreVersionConstraint = !!coreVersion ? `^${coreVersion.major}.${coreVersion.minor}.${coreVersion.patch}` : null;
        const workspace = await (0, workspace_1.getWorkspace)(tree);
        const project = workspace.projects.get(options.name);
        if (!project) {
            throw new schematics_1.SchematicsException(`project not found in workspace: ${options.name}`);
        }
        const packageJsonPath = `${project.root}/package.json`;
        const packageJson = tree.readJson(packageJsonPath);
        const packageJsonMod = {
            ...packageJson,
            dependencies: {},
            peerDependencies: {
                '@ngageoint/mage.web-app': coreVersionConstraint
            }
        };
        tree.overwrite(packageJsonPath, JSON.stringify(packageJsonMod, null, 2));
    };
}
function mageWebPluginLibrary(options) {
    if (!options.name) {
        throw new schematics_1.SchematicsException('missing name of the library to generate');
    }
    return (0, schematics_1.chain)([
        (_tree, context) => {
            context.logger.info(`creating MAGE web plugin library ${options.name}`);
        },
        (0, schematics_1.externalSchematic)('@schematics/angular', 'library', options),
        useCustomBuilder(options),
        addPluginHookToEntryPoint(options),
        addCorePeerDependency(options),
    ]);
}
//# sourceMappingURL=index.js.map