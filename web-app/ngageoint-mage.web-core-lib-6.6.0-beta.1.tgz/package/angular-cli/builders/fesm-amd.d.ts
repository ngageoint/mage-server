declare const _default: import("@angular-devkit/architect").Builder<any>;
export default _default;
