"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const build_angular_1 = require("@angular-devkit/build-angular");
const architect_1 = require("@angular-devkit/architect");
const rollup_1 = require("rollup");
const discover_packages_1 = require("ng-packagr/src/lib/ng-package/discover-packages");
const plugin_node_resolve_1 = require("@rollup/plugin-node-resolve");
const plugin_commonjs_1 = require("@rollup/plugin-commonjs");
const promises_1 = require("fs/promises");
function firstValueFromSubscribable(source) {
    return new Promise((resolve, reject) => {
        let done = false;
        let subscription;
        subscription = source.subscribe((value) => {
            if (done)
                return;
            done = true;
            if (subscription && typeof subscription.unsubscribe === 'function') {
                subscription.unsubscribe();
            }
            resolve(value);
        }, (err) => {
            if (done)
                return;
            done = true;
            reject(err);
        });
    });
}
async function ngPackagrThenAmd(options, context) {
    let ngPackagrResult;
    try {
        ngPackagrResult = await firstValueFromSubscribable((0, build_angular_1.executeNgPackagrBuilder)(options, context));
    }
    catch (err) {
        const message = err instanceof Error ? err.stack || err.message : String(err);
        context.logger.error(message);
        return {
            success: false,
            error: message
        };
    }
    if (ngPackagrResult.error) {
        context.logger.error(ngPackagrResult.error);
    }
    if (!ngPackagrResult.success) {
        return ngPackagrResult;
    }
    const buildInfo = await resolveBuildInfo(options, context);
    const rollupResult = await rollupFesmToAmd(buildInfo);
    if (!rollupResult.success) {
        return rollupResult;
    }
    return await writeDistPackageJson(buildInfo);
}
async function resolveBuildInfo(options, context) {
    const root = context.workspaceRoot;
    const ngPackagePath = path.resolve(root, options.project);
    const packages = await (0, discover_packages_1.discoverPackages)({ project: ngPackagePath });
    const destDir = packages.dest;
    const fesm2022Path = packages.primary.destinationFiles.fesm2022;
    const amdName = `${packages.primary.flatModuleFile}.amd.js`;
    const amdPath = path.resolve(destDir, amdName);
    return {
        options,
        context,
        packages,
        ngPackagePath,
        destDir,
        fesm2022Path,
        amdName,
        amdPath
    };
}
async function rollupFesmToAmd(buildInfo) {
    const { context, fesm2022Path, amdPath } = buildInfo;
    context.logger.info(`rolling FESM2022 to AMD ${JSON.stringify({
        fesm2022Path,
        amdPath
    }, null, 2)}`);
    try {
        const roller = await (0, rollup_1.rollup)({
            input: fesm2022Path,
            plugins: [
                (0, plugin_node_resolve_1.nodeResolve)({
                    resolveOnly: (moduleId) => {
                        const external = false
                            || moduleId.startsWith('@angular/')
                            || moduleId.startsWith('@ng-select/')
                            || /^rxjs(\/.+)?/.test(moduleId);
                        return !external;
                    },
                    preferBuiltins: false
                }),
                (0, plugin_commonjs_1.default)()
            ]
        });
        const rolled = await roller.write({
            format: 'amd',
            file: amdPath
        });
        for (const rollOut of rolled.output) {
            context.logger.info(`rolled ${rollOut.name} ${rollOut.type} ${rollOut.fileName}`);
        }
        return { success: true };
    }
    catch (err) {
        const message = err instanceof Error ? err.stack || err.message : String(err);
        context.logger.error('error creating amd module from fesm: ' + message);
        console.error(err);
        return {
            success: false,
            error: message
        };
    }
}
async function writeDistPackageJson(buildInfo) {
    const distPkg = {
        ...buildInfo.packages.primary.packageJson,
        main: buildInfo.amdName
    };
    const distPkgPath = path.resolve(buildInfo.packages.primary.destinationPath, 'package.json');
    const distPkgContent = JSON.stringify(distPkg, null, 2);
    try {
        buildInfo.context.logger.info(`writing dist package to ${distPkgPath}`);
        await (0, promises_1.writeFile)(distPkgPath, distPkgContent);
    }
    catch (err) {
        const message = err instanceof Error ? err.stack || err.message : String(err);
        buildInfo.context.logger.error(`error writing dist package ${distPkgPath}: ${message}`);
        return {
            success: false,
            error: message
        };
    }
    return { success: true };
}
exports.default = (0, architect_1.createBuilder)(ngPackagrThenAmd);
//# sourceMappingURL=fesm-amd.js.map