var util = require('util');
var server = require('./server');
var router = require('./router');
var requestHandlers = require('./requestHandlers');

util.puts('Setting up hanlder');

var handle = {};
handle['/'] = requestHandlers.start;
handle['/start'] = requestHandlers.start;
handle['/upload'] = requestHandlers.upload;
handle['/show'] = requestHandlers.show;

server.start(router.route, handle);
